plot_returnlevels <- function(mdl, cov_f, cov_cf, ev, seed = 42, nsamp = 500, model_desc = T,
                              xlim = c(1,10000), ylim = NA, pch = 20, xlab = "Return period (years)", 
                              ylab = NA, main = "", legend_pos = "topright", 
                              legend_labels = c("Present climate", "Counterfactual climate")) {
  
  x <- mdl$x
  if(missing(ev)) { ev <- mdl$ev }
  
  rp_x <- unique(c(seq(1.1,2,0.1), seq(2,100,1), seq(100,1000,10), seq(1000,10000,1000)))   
  rp_th <- 1/seq(1,0,length.out = length(x)+2)[2:(length(x)+1)]  
  
  # Trim covariates if necessary
  if(nrow(cov_f) > 1) {
    warning("cov_f has more than one row: only first row will be used as factual covariates")
    cov_f <- cov_f[1,,drop = F]
  }
  if(nrow(cov_cf) > 1) {
    warning("cov_cf has more than one row: only first row will be used as counterfactual covariates")
    cov_cf <- cov_cf[1,,drop = F]
  }
  
  # Calculate return levels
  rl_curve_pres <- map_from_u(mdl, 1/rp_x, fixed_cov = cov_f)
  rl_curve_cf <- map_from_u(mdl, 1/rp_x, fixed_cov = cov_cf)
  
  rl_obs_pres <- map_from_u(mdl, map_to_u(mdl), fixed_cov = cov_f)
  rl_obs_cf <- map_from_u(mdl, map_to_u(mdl), fixed_cov = cov_cf)
  
  rp_event_pres <- 1/map_to_u(mdl, ev, fixed_cov = cov_f)
  rp_event_cf <- 1/map_to_u(mdl, ev, fixed_cov = cov_cf)
  
  # Store event return period values
  event_rp_values <- list(present = rp_event_pres, counterfactual = rp_event_cf)
  
  # Prep axes
  if(is.na(ylim[1])) { ylim <- range(pretty(c(x, rl_curve_pres, rl_curve_cf))) }
  if(is.na(ylab)) { ylab <- mdl$varnm }
  
  # Plot
  plot(0, type = "n", xlim = xlim, ylim = ylim, log = "x", xlab = "", ylab = "", main = main)
  mtext(xlab, side = 1, line = 2.5, cex = par("cex.lab"))
  mtext(ylab, side = 2, line = 2.5, cex = par("cex.lab"))
  
  # Add legend
  legend_title <- if (model_desc) paste0(mdl$varnm, " ~ ", paste0(mdl$covnm, collapse = " + "), " (",mdl$dist, ", ", mdl$type, ")") else ""
  legend(legend_pos, legend = c(legend_labels, "Observed event"), col = c("firebrick", "blue", "magenta"), 
         lty = 1, pch = c(pch, pch, NA), bty = "n", cex = par()$cex.lab, title = legend_title)
  
  # Plot return period curves
  lines(rp_x, rl_curve_pres, lwd = 2, col = "firebrick", lty = 1)    
  lines(rp_x, rl_curve_cf, lwd = 2, col = "blue", lty = 1) 
  
  # expected return periods vs return levels transformed to stationarity at that covariate value
  points(rp_th, sort(rl_obs_pres, decreasing = mdl$lower), col = "firebrick", pch = pch)      # present
  points(rp_th, sort(rl_obs_cf, decreasing = mdl$lower), col = "blue", pch = pch)             # counterfactual
  
  # Add observed event line and ticks
  abline(h = ev, col = "magenta", lty = 2)
  suppressWarnings(rug(rp_event_pres, lwd = 3, col = "firebrick"))   
  suppressWarnings(rug(rp_event_cf, lwd = 3, col = "blue"))          
  
  # Confidence Intervals
  crossings <- list()
  if(!is.na(nsamp)) {
    x_ci <- c(1,2,3,4, 5,10,20,50,100,200,500,1000,2000,5000,10000)
    set.seed(seed)
    
    mdl_df <- mdl$data[,c(mdl$varnm, mdl$covnm)]
    boot_res <- sapply(1:nsamp, function(i) {
      boot_df <- mdl_df[sample(1:nrow(mdl_df), nrow(mdl_df), replace = T),]
      tryCatch({
        boot_mdl <- refit(mdl, boot_df)
        c(map_from_u(boot_mdl, 1/x_ci, fixed_cov = cov_f), 
          map_from_u(boot_mdl, 1/x_ci, fixed_cov = cov_cf))
      }, error = function(cond) {return(rep(NA, length(x_ci)*2))})
    })
    est_ci <- apply(boot_res, 1, quantile, c(0.025, 0.975), na.rm = T)
    
    # Add shaded region for confidence intervals
    polygon(x = c(x_ci, rev(x_ci)), 
            y = c(est_ci[1,1:length(x_ci)], rev(est_ci[2,1:length(x_ci)])), 
            density = NULL, border = NA, col = adjustcolor("firebrick", 0.1))
    polygon(x = c(x_ci, rev(x_ci)), 
            y = c(est_ci[1,-(1:length(x_ci))], rev(est_ci[2,-(1:length(x_ci))])), 
            density = NULL, border = NA, col = adjustcolor("blue", 0.1))
    
    # Function to find confidence interval crossing points
    find_crossings <- function(x_vals, lower_vals, upper_vals, event_value) {
      crossings_x <- c()
      
      for (i in seq_along(x_vals[-1])) {
        # Check if the event line crosses the lower bound
        if ((lower_vals[i] <= event_value && lower_vals[i+1] >= event_value) || 
            (lower_vals[i] >= event_value && lower_vals[i+1] <= event_value)) {
          x_cross <- x_vals[i] + (event_value - lower_vals[i]) * 
            (x_vals[i+1] - x_vals[i]) / (lower_vals[i+1] - lower_vals[i])
          crossings_x <- c(crossings_x, x_cross)
        }
        # Check if the event line crosses the upper bound
        if ((upper_vals[i] <= event_value && upper_vals[i+1] >= event_value) || 
            (upper_vals[i] >= event_value && upper_vals[i+1] <= event_value)) {
          x_cross <- x_vals[i] + (event_value - upper_vals[i]) * 
            (x_vals[i+1] - x_vals[i]) / (upper_vals[i+1] - upper_vals[i])
          crossings_x <- c(crossings_x, x_cross)
        }
      }
      return(sort(crossings_x))
    }
    
    # Get x-coordinates of crossing points
    crossings$present <- find_crossings(x_ci, est_ci[1,1:length(x_ci)], est_ci[2,1:length(x_ci)], ev)
    crossings$counterfactual <- find_crossings(x_ci, est_ci[1,-(1:length(x_ci))], est_ci[2,-(1:length(x_ci))], ev)
  }
  
  # Return extracted values
  return(list(event_rp_values = event_rp_values, crossings = crossings))
}


a<-plot_returnlevels(mdl=mdl_ninopos, cov_f = cov_2023, cov_cf = cov_cf["hist",,drop = F], nsamp = 1000, ylab = "SPEI", ylim = ylim,
                     main = "Current climate vs preindustrial")

# Extract event return periods
a$event_rp_values

# Extract confidence interval crossing points
a$crossings
